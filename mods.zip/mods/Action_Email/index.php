<?php 
/*
Autoload classes
-------------------------
*/
wpseed_load_dir_classes(__DIR__ . '/Action', '\PBOOT\Mod\Action_Email\Action');
wpseed_load_dir_classes(__DIR__ . '/Type/Reg', '\PBOOT\Mod\Action_Email\Type\Reg');
