<?php 
/*
Autoload classes
-------------------------
*/
wpseed_load_dir_classes(__DIR__ . '/Action', '\PBOOT\Mod\User_Login\Action');
