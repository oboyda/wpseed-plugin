<?php 

namespace PBOOT\Mod\User_Login\View;

class User_Login extends \PBOOT\View\View 
{
    function __construct($args)
    {
        parent::__construct($args, [
            
        ]);
    }
}