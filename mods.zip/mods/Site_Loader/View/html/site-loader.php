<div class="<?php echo $view->getHtmlClass('ta-center'); ?>">
    <div class="spinner-grow" role="status"></div>
</div>