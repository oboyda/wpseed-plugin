<?php

namespace PBOOT\Mod\Site_Loader\View;

class Site_Loader extends \PBOOT\View\View 
{
    public function __construct($args)
    {
        parent::__construct($args, [
            
        ]);
    }
}
