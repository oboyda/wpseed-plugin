<div class="<?php echo $view->getHtmlClass(); ?>">
    <h3 class="item-title"><?php echo $view->item->getTitle(); ?></h3>
</div>