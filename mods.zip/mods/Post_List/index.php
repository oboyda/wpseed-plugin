<?php 

/*
Autoload classes
-------------------------
*/
wpseed_load_dir_classes(dirname(__FILE__) . '/Action', '\PBOOT\Mod\Post_List\Action');
