<?php 
/*
Autoload classes
-------------------------
*/
// wpseed_load_dir_classes(__DIR__ . '/Action', '\PBOOT\Mod\Status_Message\Action');
